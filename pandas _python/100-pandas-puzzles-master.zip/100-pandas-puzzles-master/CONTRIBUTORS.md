# Contributors

Many thanks to the following contributors for their puzzles and fixes.

## Puzzles

- [@johink](https://github.com/johink) - the plotting puzzles 56-60

## Solutions

- [@madrury](https://github.com/madrury) - third solution to puzzle 29
- [@xonoma](https://github.com/xonoma) - non-`ix` solution to puzzle 8

## Fixes

- [pleydier](https://github.com/pleydier) - fix for puzzle 29
- [g-morishita](https://github.com/g-morishita) - fix typo in puzzle 27
- [499244188](https://github.com/499244188) - requirements.txt
- [@guiem](https://github.com/guiem) - typo in README
- [@johnny5550822](https://github.com/johnny5550822) - fix to puzzle 24
